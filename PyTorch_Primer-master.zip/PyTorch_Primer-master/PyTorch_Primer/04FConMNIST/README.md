PyTorch搭建多层全连接神经网络实现MNIST手写数字识别分类
---------------------
详细讲解见博客：[FC实现MNIST手写数字分类](https://blog.csdn.net/out_of_memory_error/article/details/81414986)